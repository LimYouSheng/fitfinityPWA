# Fitfinity Prototype v0.32 UI Fixes

Built from the verified v0.31 refactored baseline.

## Changes

1. **iPad duplicate page header**
   - Keeps the portal title beside the Home button.
   - Removes the duplicate top-level page title inside the body on touch tablets from 781px through 1366px, including larger iPad landscape sizes.
   - Page-level action buttons remain available when the duplicate title is removed.

2. **Readonly client/trainer detail views**
   - Fixes hidden phone edit groups that were being forced visible by a later `display:flex !important` rule.
   - Fixes generated in-app picker buttons for hidden edit-mode `<select>` controls, so Gender/Public profile/Account status fields do not appear until Edit mode is actually active.

3. **Session Details → Exercise Plan**
   - Saved exercise rows and the column header now share one six-column grid.
   - Weight, Reps, Rounds and Rest line up consistently across saved rows.
   - A reserved final camera column keeps the camera icon at the far right without shifting the data columns.
   - Camera icon moved upward.

4. **Remuneration cycle trainer records**
   - Trainer name, session/remuneration/status summary and View action now remain on one horizontal record instead of appearing as three stacked lines.

5. **Owner Dashboard → Requests**
   - Adds the request status pill to each dashboard request preview row.
   - Existing dashboard request filtering/workflow is unchanged.

## Implementation

New patch files only:
- `assets/css/v032-ui-fixes.css`
- `assets/js/v032-ui-fixes.js`

The v0.31 refactored core and historical compatibility files remain intact.
