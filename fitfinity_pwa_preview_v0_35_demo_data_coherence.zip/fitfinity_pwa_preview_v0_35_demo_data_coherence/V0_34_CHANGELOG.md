# Fitfinity v0.34 — Mobile Renewals Consistency

- Mobile Owner Dashboard **Upcoming Renewals** now matches the compact sizing of **Requests**.
- Matching mobile panel padding, header height, heading size, View All button size and row density.
- Renewal records collapse to one compact row on mobile: client, session count, renewal status and View Client.
- Desktop/tablet renewal layouts are unchanged.
- PWA cache bumped to `fitfinity-staff-ui-v34-mobile-renewals`.
