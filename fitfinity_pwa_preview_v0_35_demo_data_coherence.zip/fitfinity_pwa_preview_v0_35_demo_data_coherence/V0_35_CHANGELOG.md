# Fitfinity v0.35 — Demo Data Coherence

## Client records
- Populated contact, age, gender, emergency contact, start date, remarks and health/limitation notes for every demo client.
- Added coherent package metadata and weekly frequency for all 12 demo client records.
- Client profile avatar, primary trainer, package end and trainer assignment now follow the selected client.

## Package / session coherence
- Removed the Amanda-only 3/12 package behaviour from other client profiles.
- Current Package summary now uses the selected client's real demo values.
- Cheryl Tan now correctly shows 10 completed sessions, matching Upcoming Renewals.
- Session History and Upcoming Sessions are generated from the same package record, so counts agree.
- 12-session packages contain 12 sessions. 24-week packages use the selected weekly frequency to determine the complete appointment count.
- Future bookings were moved beyond 30 Aug 2026 so planned sessions are not shown as already-past appointments.
- Generated demo sessions include exercise-plan content when opened.
- Progress data varies per client instead of displaying Amanda's exact strength values for everyone.

## Trainer records
- Normalised all trainer phone, gender and qualification fields so trainer profiles do not fall back to blank/demo placeholders.
- Existing availability, rates, assigned clients and remuneration data remain intact.

## Requests
- Corrected the seeded trainer-change request so its linked session belongs to Amanda Lim / Marcus Tan.

## PWA
- Cache version advanced to `fitfinity-staff-ui-v35-demo-data`.
